import 'package:dartz/dartz.dart';
import 'package:movie/domain/entities/tv.dart';
import 'package:movie/domain/repositories/tv_repository.dart';
import 'package:movie/common/failure.dart';

class GetNowPlayingTv {
  final TvRepository repository;

  GetNowPlayingTv(this.repository);

  Future<Either<Failure, List<Tv>>> execute() {
    return repository.getNowPlayingTv();
  }
}