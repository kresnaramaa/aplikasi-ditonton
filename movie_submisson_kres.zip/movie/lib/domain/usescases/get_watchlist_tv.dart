import 'package:dartz/dartz.dart';
import 'package:movie/domain/entities/tv.dart';
import 'package:movie/domain/repositories/tv_repository.dart';
import 'package:movie/common/failure.dart';

class GetWatchlistTv {
  final TvRepository _repository;

  GetWatchlistTv(this._repository);

  Future<Either<Failure, List<Tv>>> execute() {
    return _repository.getWatchlistTv();
  }
}